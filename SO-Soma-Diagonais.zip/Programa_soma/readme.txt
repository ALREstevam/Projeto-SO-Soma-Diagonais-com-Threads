Arquivo execut�vel pode ser gerado pelo comando make e executado com o comando ./projso.o. 

Os valores a inserir na matriz devem estar no arquivo: in.txt. 

Os valores de sa�da ser�o escritos nos arquivos: out_sol_A.txt e out_sol_B.txt. 

As dimens�es M e N da matriz e a quantidade de threads T devem ser inseridos pelo usu�rio pelo terminal. 

Para sair do programa insira 0 em todas as entradas do terminal.