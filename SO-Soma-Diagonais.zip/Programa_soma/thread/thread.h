#ifndef THREAD_H
#define THREAD_H

#include "../datadefine.h"

void * threadSumFunc_A(void * args);
void * threadSumFunc_B(void * args);

#endif //PROJSO_THREAD_H
