//
// Created by andre on 03/05/2017.
//

#ifndef PROJSOTEST_THREAD_H
#define PROJSOTEST_THREAD_H

#include "../datadefine.h"

void * threadSumFunc(void * args);

#endif //PROJSOTEST_THREAD_H
