#ifndef UDATA_H
#define UDATA_H
#include <pthread.h>
#include "threadArgsInfo.h"

//Tipo de dado para armazenar v�rios dados


#endif