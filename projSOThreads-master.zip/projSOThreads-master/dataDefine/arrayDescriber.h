#ifndef ARRAYDESCRIBER_H
#define ARRAYDESCRIBER_H


#include "udata.h"
#include "threadArgsInfo.h"



#endif