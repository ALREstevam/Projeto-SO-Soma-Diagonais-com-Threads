#ifndef THREADARGSINFO_H
#define THREADARGSINFO_H
#include "matrixDescriber.h"
#include "arrayDescriber.h"

//Par�metros para thread de soma




#endif